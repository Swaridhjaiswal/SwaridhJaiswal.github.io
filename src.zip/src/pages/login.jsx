import React from 'react'

const login = () => {
  return (
    <div>
      this is console.log
    </div>
  )
}

export default login
