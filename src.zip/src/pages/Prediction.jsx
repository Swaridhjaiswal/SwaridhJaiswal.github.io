import { useState } from 'react';
import './prediction.css';


function App() {
  const A = {
    select1: "",
    select2: "",
    select3: "",
    select4: "",
    select5: "",
    select6: ""
  };

  const [use, function_operation] = useState(A);

  function function_change(event) {
    function_operation((item) => {
      return {
        ...item,
        [event.target.name]: event.target.value
      }
    });
  }

  async function funsubmit(event) {
    event.preventDefault();

  }


  return (
    <div className="predicition_div">
<p>Select your symptoms</p>
<form onSubmit={funsubmit}>
     <label htmlFor="select1">symptoms1:-</label>

<select
name="select1"
id="cars"
className='select_class'
onChange={function_change}>
  <option  value="">--option--</option>
  <option  value="volvo">Volvo</option>
  <option  value="saab">Saab</option>
  <option  value="mercedes">Mercedes</option>
  <option  value="audi">Audi</option>
</select>

<label htmlFor="select2">symptoms2:-</label>
<select
className='select_class'
name="select2"
id="cars"
onChange={function_change}>
  <option  value="">--option--</option>
  <option  value="volvo">Volvo</option>
  <option  value="saab">Saab</option>
  <option  value="mercedes">Mercedes</option>
  <option  value="audi">Audi</option>
</select>

<label htmlFor="select3">symptoms3:-</label>
<select
name="select3"
id="cars"
className='select_class'
onChange={function_change}>
  <option  value="">--option--</option>
  <option  value="volvo">Volvo</option>
  <option  value="saab">Saab</option>
  <option  value="mercedes">Mercedes</option>
  <option  value="audi">Audi</option>
</select>

<label htmlFor="select4">symptoms4:-</label>
<select
name="select4"
id="cars"
className='select_class'
onChange={function_change}>
  <option  value="">--option--</option>
  <option  value="volvo">Volvo</option>
  <option  value="saab">Saab</option>
  <option  value="mercedes">Mercedes</option>
  <option  value="audi">Audi</option>
</select>

<label htmlFor="select5">symptoms5:-</label>
<select
name="select5"
id="cars"
className='select_class'
onChange={function_change}>
  <option  value="">--option--</option>
  <option  value="volvo">Volvo</option>
  <option  value="saab">Saab</option>
  <option  value="mercedes">Mercedes</option>
  <option  value="audi">Audi</option>
</select>

<label htmlFor="select6">symptoms6:-</label>
<select
name="select6"
id="cars"
className='select_class'
onChange={function_change}>
  <option  value="">--option--</option>
  <option  value="volvo">Volvo</option>
  <option  value="saab">Saab</option>
  <option  value="mercedes">Mercedes</option>
  <option  value="audi">Audi</option>
</select>

<button >Submit</button>
</form>
    </div>
  );
}

export default App;
