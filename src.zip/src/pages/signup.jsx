import React from 'react'

const signup = () => {
  return (
    <div>
        this is signup
    </div>
  )
}

export default signup
